#!/bin/bash

#set -e

BROWSER="firefox"

# The $! parameter stores the background process PID, while $? stores the exit status. The exit status 0 indicates the command finished successfully.

# All function parameters or arguments can be accessed via $1, $2, $3,..., $N.
# $0 always point to the shell script name.
# $* or $@ holds all parameters or arguments passed to the function.
# $# holds the number of positional parameters passed to the function.

function is_running {
   RUNNING=$(docker inspect --format="{{.State.Running}}" $1 2> /dev/null)

   if [[ "$RUNNING" == "false" ]]; then
      return 0
    else
      return 1
   fi
      
}

function start_container {
   docker start HTB
}

function stop_container {
   docker stop HTB
}

function launch_browser {
   nohup $BROWSER --allow-downgrade --no-remote -P HTB >/dev/null &
   PID=$1
   wait $PID
   stop_container
}

is_running HTB
if [[ $? -eq 1 ]]; then
      echo "HTB container is already running!"
   else
      echo "Staring HTB container"
      start_container
fi

launch_browser

